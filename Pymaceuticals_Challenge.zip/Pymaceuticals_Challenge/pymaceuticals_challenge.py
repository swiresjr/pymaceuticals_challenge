#!/usr/bin/env python
# coding: utf-8

# # Pymaceuticals Inc.
# ---
# 
# ### Analysis
# - Based on the data frames and graphs, I was able to draw the following conclusions:
#     - Capomulin and Ramicane had significantly higher timepoints than the other regimens.
#     - Capomulin and Ramicane had significantly lower statistical values than the other regimens.
#     - The quantities of male and female mice were approximately evenly distributed. 
#  

# In[1]:


# Dependencies and Setup
import matplotlib.pyplot as plt
import pandas as pd
import scipy.stats as st
import statistics 

# Study data files
mouse_metadata_path = "data/Mouse_metadata.csv"
study_results_path = "data/Study_results.csv"

# Read the mouse data and the study results
mouse_metadata = pd.read_csv(mouse_metadata_path)
study_results = pd.read_csv(study_results_path)

# Combine the data into a single DataFrame
metadata_df = pd.DataFrame(mouse_metadata, columns=["Mouse ID","Drug Regimen","Sex","Age_months","Weight (g)"])
results_df = pd.DataFrame(study_results, columns=["Mouse ID", "Timepoint","Tumor Volume (mm3)","Metastatic Sites"])

merge_df = pd.merge(results_df, metadata_df , on="Mouse ID")

# Display the data table for preview
merge_df.head()


# In[2]:


# Checking the number of mice.
miceCount = mouse_metadata['Mouse ID'].count()
miceCount


# In[3]:


# Our data should be uniquely identified by Mouse ID and Timepoint
# Get the duplicate mice by ID number that shows up for Mouse ID and Timepoint.
duplicateID = merge_df.duplicated(subset=['Mouse ID', 'Timepoint'], keep=False)

print(merge_df[duplicateID]['Mouse ID'].unique())


# In[4]:


# Optional: Get all the data for the duplicate mouse ID.
mouse_df = merge_df[merge_df['Mouse ID'] == "g989"]
mouse_df


# In[5]:


# Create a clean DataFrame by dropping the duplicate mouse by its ID.
clean_df = merge_df[merge_df['Mouse ID'] != "g989"]
clean_df.head()


# In[6]:


# Checking the number of mice in the clean DataFrame.
miceCount_clean = clean_df['Mouse ID'].value_counts()
print(len(miceCount_clean))


# ## Summary Statistics

# In[7]:


# Generate a summary statistics table of mean, median, variance, standard deviation, and SEM of the tumor volume for each regimen

# Use groupby and summary statistical methods to calculate the following properties of each drug regimen:
summary_stats_df_mean = clean_df.groupby('Drug Regimen')["Tumor Volume (mm3)"].mean()
summary_stats_df_median = clean_df.groupby('Drug Regimen')["Tumor Volume (mm3)"].median()
summary_stats_df_variance = clean_df.groupby('Drug Regimen')["Tumor Volume (mm3)"].var()
summary_stats_df_stdev = clean_df.groupby('Drug Regimen')["Tumor Volume (mm3)"].std()
summary_stats_df_sem = clean_df.groupby('Drug Regimen')["Tumor Volume (mm3)"].sem ()
# mean, median, variance, standard deviation, and SEM of the tumor volume.
# Assemble the resulting series into a single summary DataFrame.
summary_stats_df = pd.DataFrame({"Mean Tumor Volume": summary_stats_df_mean,
                                "Median Tumor Volume": summary_stats_df_median,
                                "Tumor Volume Variance": summary_stats_df_variance,
                                "Tumor Volume Std. Dev.": summary_stats_df_stdev,
                                "Tumor Volume Std. Err.": summary_stats_df_sem})
summary_stats_df


# In[8]:


# A more advanced method to generate a summary statistics table of mean, median, variance, standard deviation,
# and SEM of the tumor volume for each regimen (only one method is required in the solution)

# Using the aggregation method, produce the same summary statistics in a single line
summary_stats_df_agg = clean_df.groupby('Drug Regimen')['Tumor Volume (mm3)'].agg(['mean', 'median', 'var', 'std', 'sem'])
summary_stats_df_agg


# ## Bar and Pie Charts

# In[9]:


# Generate a bar plot showing the total number of rows (Mouse ID/Timepoints) for each drug regimen using Pandas.
drug_regimen_rows = clean_df.groupby('Drug Regimen').size()
drug_regimen_rows.plot(kind='bar', figsize=(10, 5), color='blue')
plt.title('Total Number of Timepoints for Each Drug Regimen')
plt.xlabel('Drug Regimen')
plt.ylabel('Number of Timepoints')
plt.xticks(rotation=45)
plt.show()


# In[10]:


# Generate a bar plot showing the total number of rows (Mouse ID/Timepoints) for each drug regimen using pyplot.
plt.figure(figsize=(10, 5))
plt.bar(drug_regimen_rows.index, drug_regimen_rows.values, color='lightblue')
plt.title('Total Number of Timepoints for Each Drug Regimen')
plt.xlabel('Drug Regimen')
plt.ylabel('Number of Timepoints')
plt.xticks(rotation=45)
plt.show()


# In[11]:


# Generate a pie chart, using Pandas, showing the distribution of unique female versus male mice used in the study
unique_mice = clean_df.drop_duplicates(subset='Mouse ID')
# Get the unique mice with their gender
sex_counts = unique_mice['Sex'].value_counts()

# Make the pie chart
sex_counts.plot(kind='pie', autopct='%1.1f%%', figsize=(8, 8), startangle=90, colors=['lightblue', 'pink'])
plt.title('Distribution of Unique Female vs Male Mice')
plt.ylabel('')  # Hide the y-label
plt.show()


# In[12]:


# Generate a pie chart, using pyplot, showing the distribution of unique female versus male mice used in the study
unique_mice = clean_df.drop_duplicates(subset='Mouse ID')
# Get the unique mice with their gender
sex_counts = unique_mice['Sex'].value_counts()

# Make the pie chart
plt.figure(figsize=(8, 8))
plt.pie(sex_counts, labels=sex_counts.index, autopct='%1.1f%%', startangle=90, colors=['lightblue', 'pink'])
plt.title('Distribution of Unique Female vs Male Mice')
plt.axis('equal')  # Equal aspect ratio ensures that pie chart is circular
plt.show()


# ## Quartiles, Outliers and Boxplots

# In[13]:


# Calculate the final tumor volume of each mouse across four of the treatment regimens:
# Capomulin, Ramicane, Infubinol, and Ceftamin
# Start by getting the last (greatest) timepoint for each mouse
final_timepoints = clean_df.groupby('Mouse ID')['Timepoint'].last().reset_index()

# Merge this group df with the original DataFrame to get the tumor volume at the last timepoint
timepoint_df = pd.merge(final_timepoints, clean_df, on=['Mouse ID', 'Timepoint'])

# Merge with the original DataFrame to get the tumor volume at the last timepoint
final_tumor_volumes = timepoint_df[['Drug Regimen', 'Tumor Volume (mm3)']]


# In[14]:


# Put treatments into a list for for loop (and later for plot labels)
mice_treatment = ['Capomulin', 'Ramicane', 'Infubinol', 'Ceftamin']
# Create empty list to fill with tumor vol data (for plotting)
tumor_vol_data = []

# Calculate the IQR and quantitatively determine if there are any potential outliers.
for treatment in mice_treatment:

    # Locate the rows which contain mice on each drug and get the tumor volumes
    treatment_data = clean_df[clean_df['Drug Regimen'] == treatment]['Tumor Volume (mm3)']
    
    # add subset
    tumor_vol_data.append(treatment_data)
    # Interquartile range
    Q1 = treatment_data.quantile(0.25)
    Q3 = treatment_data.quantile(0.75)
    IQR = Q3 - Q1
    # Determine outliers using upper and lower bounds
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    # Identify potential outliers
    outliers = treatment_data[(treatment_data < lower_bound) | (treatment_data > upper_bound)]
    
    # Print out the outliers for the current treatment
    print(f"{treatment} potential outliers: {outliers.values}")


# In[15]:


# Generate a box plot that shows the distribution of the tumor volume for each treatment group.
plt.figure(figsize=(10, 6))
plt.boxplot(tumor_vol_data, labels=mice_treatment, patch_artist=True, boxprops=dict(facecolor='lightblue'))
plt.title('Distribution of Tumor Volume by Treatment Group')
plt.xlabel('Drug Regimen')
plt.ylabel('Tumor Volume (mm3)')
plt.grid(axis='y')
plt.show()


# ## Line and Scatter Plots

# In[16]:


# Generate a line plot of tumor volume vs. time point for a single mouse treated with Capomulin
mouse_id = 'l509'  # Replace with the desired Mouse ID
mouse_capomulin_data = clean_df[(clean_df['Mouse ID'] == mouse_id) & (clean_df['Drug Regimen'] == 'Capomulin')]
plt.figure(figsize=(10, 6))
plt.plot(mouse_capomulin_data['Timepoint'], mouse_capomulin_data['Tumor Volume (mm3)'], color='slateblue', linestyle='-')
plt.title(f'Capomulin Treatment of mouse {mouse_id}')
plt.xlabel('Time Point (Days)')
plt.ylabel('Tumor Volume (mm3)')
plt.xticks(mouse_capomulin_data['Timepoint']) 
plt.grid()
plt.show()


# In[17]:


# Generate a scatter plot of mouse weight vs. the average observed tumor volume for the entire Capomulin regimen
capomulin_data = clean_df[clean_df['Drug Regimen'] == 'Capomulin']
average_tumor_volume = capomulin_data.groupby('Weight (g)')['Tumor Volume (mm3)'].mean().reset_index()
plt.figure(figsize=(10, 6))
plt.scatter(average_tumor_volume['Weight (g)'], average_tumor_volume['Tumor Volume (mm3)'], color='blue', alpha=0.5)
plt.title('Mouse Weight vs. Average Tumor Volume for Capomulin Regimen')
plt.xlabel('Weight (g)')
plt.ylabel('Average Tumor Volume (mm3)')
plt.grid(True)
plt.show()


# ## Correlation and Regression

# In[18]:


# Calculate the correlation coefficient and a linear regression model
correlation = average_tumor_volume['Weight (g)'].corr(average_tumor_volume['Tumor Volume (mm3)'])
print(f"The correlation between mouse weight and the average tumor volume is: {correlation.round(2)}")
# for mouse weight and average observed tumor volume for the entire Capomulin regimen
slope, intercept, r_value, p_value, std_err = st.linregress(average_tumor_volume['Weight (g)'], average_tumor_volume['Tumor Volume (mm3)'])
regress_values = slope * average_tumor_volume['Weight (g)'] + intercept
plt.figure(figsize=(10, 6))
plt.plot(average_tumor_volume['Weight (g)'], regress_values, color='red')
plt.scatter(average_tumor_volume['Weight (g)'], average_tumor_volume['Tumor Volume (mm3)'], color='blue', alpha=0.5)
plt.title('Mouse Weight vs. Average Tumor Volume for Capomulin Regimen')
plt.xlabel('Weight (g)')
plt.ylabel('Average Tumor Volume (mm3)')
plt.grid(True)
plt.show()


# In[ ]:




